# Sync activado 🚀
Activa GitHub Actions
