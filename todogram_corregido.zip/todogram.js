#!/usr/bin/env node
import readline from 'readline';
import chalk from 'chalk';
import { exec } from 'child_process';
import figlet from 'figlet';

class TodogramCLI {
  constructor() {
    this.menuItems = [
      { label: '🚀 Obtener datos de Notion y TMDB', command: 'npm run start' },
      { label: '🤖 Iniciar auto-push automático', command: 'node auto-push.js' },
      { label: '🪵 Ver logs en tiempo real', command: 'pm2 logs auto-push' },
      { label: '📦 Push completo con resolución', command: 'git push' },
      { label: '⚡ Forzar workflow GitHub Actions', command: 'gh workflow run sync.yml' },
      { label: '🌐 Deploy en GitHub Pages', command: 'npm run deploy:gh' },
      { label: '🚀 Desplegar en Netlify/Vercel', command: 'echo "deploy script aquí"' },
      { label: '⏹️ Detener proceso PM2 auto-push', command: 'pm2 stop auto-push' },
      { label: '🔄 Reiniciar procesos PM2', command: 'pm2 restart all' }
    ];
    this.selectedIndex = 0;
    this.lastRenderedMenu = '';
    this.stdin = process.stdin;
    this.stdout = process.stdout;
    this.running = true;
    this.init();
  }

  init() {
    this.stdin.setRawMode(true);
    this.stdin.resume();
    this.stdin.setEncoding('utf8');

    this.stdin.removeAllListeners('data');
    this.stdin.on('data', this.handleKeyPress.bind(this));

    this.showMainMenu();
  }

  clearScreen() {
    this.stdout.write('\x1B[2J\x1B[0f');
  }

  showMainMenu() {
    this.clearScreen();
    const header = figlet.textSync('Todogram TV', { horizontalLayout: 'full' });
    const systemInfo = `${chalk.gray(\`NODE: \${process.version}\`)} │ ${chalk.gray(\`UPTIME: 0s\`)} │ ${chalk.gray(\`RAM: 5MB\`)}`;
    let output = `\n${chalk.cyanBright(header)}\n\n${chalk.greenBright(systemInfo)}\n\n`;

    output += '╔══════════════════════════════════════════════════════════════════════════════════════════════════╗\n';
    output += '║ 📊 OPERACIONES (1-10)                         │ 🔧 MANTENIMIENTO (11-20)                      ║\n';

    this.menuItems.forEach((item, index) => {
      const isSelected = index === this.selectedIndex;
      const prefix = isSelected ? chalk.inverse(' ◄') : '  ';
      const line = \`║ [\${String(index + 1).padEnd(2)}] \${item.label.padEnd(35)}\${prefix}\`.padEnd(84);
      output += line + ' ║\n';
    });

    output += '╚══════════════════════════════════════════════════════════════════════════════════════════════════╝\n';
    output += `\n🎮 NAVEGACIÓN: ↑↓ Mover  ENTER Ejecutar  1-9 Directo  X Salir`;
    output += `\n   Opción seleccionada: ${this.menuItems[this.selectedIndex].label}`;

    if (output !== this.lastRenderedMenu) {
      this.stdout.write(output);
      this.lastRenderedMenu = output;
    }
  }

  handleKeyPress(key) {
    if (!this.running) return;

    if (key === '\u0003') process.exit(); // Ctrl+C
    if (key === '\r') return this.executeCurrentOption();
    if (key === '\u001B\u005B\u0041') this.moveSelection(-1); // ↑
    if (key === '\u001B\u005B\u0042') this.moveSelection(1);  // ↓
    if (key.toLowerCase() === 'x') return process.exit(0);
    if (/^[0-9]+$/.test(key)) {
      const idx = parseInt(key, 10) - 1;
      if (idx >= 0 && idx < this.menuItems.length) {
        this.selectedIndex = idx;
        this.showMainMenu();
      }
      return;
    }

    setImmediate(() => this.showMainMenu());
  }

  moveSelection(delta) {
    this.selectedIndex += delta;
    if (this.selectedIndex < 0) this.selectedIndex = this.menuItems.length - 1;
    if (this.selectedIndex >= this.menuItems.length) this.selectedIndex = 0;
    this.showMainMenu();
  }

  executeCurrentOption() {
    const selected = this.menuItems[this.selectedIndex];
    this.clearScreen();
    console.log(chalk.greenBright(`\n✅ Ejecutando: ${selected.label}\n`));
    exec(selected.command, (err, stdout, stderr) => {
      if (err) {
        console.error(chalk.red('❌ Error:'), err.message);
      } else {
        console.log(chalk.white(stdout));
      }
      console.log(chalk.gray('\nPresiona cualquier tecla para volver al menú...'));
      this.stdin.once('data', () => this.showMainMenu());
    });
  }
}

new TodogramCLI();
